# Alura cursos online - Fundamentos Django 2 (Parte 3): Uma aplicação web

Projeto da Alura cursos online, desenvolvido em Python3 com framework Django

## Projeto final aula 5

Nessa aula:

- Adicionando mensagens de sucesso e erro atraves do [messages framework do Django](https://docs.djangoproject.com/en/3.0/ref/contrib/messages/);

- Melhoramos nosso código, criando funções para evitar duplicidade.
