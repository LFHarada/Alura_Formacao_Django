from django.apps import AppConfig


class PassagensConfig(AppConfig):
    name = 'passagens'
