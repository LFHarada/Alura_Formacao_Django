tipos_de_classe = {
    (1, 'Econômica'),
    (3, 'Primeira classe')
}