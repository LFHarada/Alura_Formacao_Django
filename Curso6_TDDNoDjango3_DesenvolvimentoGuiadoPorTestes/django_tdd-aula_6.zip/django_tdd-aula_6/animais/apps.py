from django.apps import AppConfig


class AnimaisConfig(AppConfig):
    name = 'animais'
