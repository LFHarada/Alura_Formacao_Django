# Alura cursos online - Fundamentos Django 2 (Parte 2): Uma aplicação web

Projeto da Alura cursos online, desenvolvido em Python3 com framework Django

## Projeto final aula 5

Nessa aula:

- Aprendemos que podemos criar usuários Django com autorizações limitadas;

- Refatoramos o código html para evitar duplicidade de código, criando a partial `_busca.html`.
